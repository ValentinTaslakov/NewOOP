package glacialExpedition.models.explorers;

public class AnimalExplorer extends BaseExplorer{

    private static final double Energy = 100;

    public AnimalExplorer(String name) {
        super(name, Energy);
    }
}
